from .compare import compare_all
